# Roadmap

## MVP
- Map + GPS, offline tiles
- Conditions panel + solunar
- Species profiles (LMB/SMB/trout)
- Tackle inventory
- Rec engine v1
- Trip log
- Regs snapshot

## Phase 2
- GPX/USR import
- Heatmaps from logs
- Live collaboration
- NMEA Wi‑Fi research
- LLM pattern explainer
