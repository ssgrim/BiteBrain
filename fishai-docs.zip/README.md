# BiteBrain (Fishing/Kayak AI Assistant)

AI that fuses local weather, seasonal bite patterns, and your tackle inventory to recommend **where/when/what** to fish—plus maps, regulations snapshots, and offline trip plans.

## Why this exists
Finding fish is pattern recognition. BiteBrain aggregates context (wind, light, season, water temps, clarity, pressure trend) and your *actual* gear to produce transparent, explainable recommendations.

---

## Monorepo layout (Turborepo-ready)
```
/apps
  /web        # Next.js app (to be scaffolded by PROMPT.md)
  /mobile     # Expo React Native app (to be scaffolded by PROMPT.md)
/packages
  /ui         # shared UI components
  /core       # scoring engine & species/season data (TypeScript)
/services
  /api        # Node/TS handlers (serverless)
/infra
  /terraform  # AWS IaC (API, DynamoDB, S3, CloudFront, Cognito)
/docs         # living documentation
```

## Quick start
1. Open in **GitHub Codespaces**.
2. Open `PROMPT.md` and run it with Codespaces AI to scaffold the apps.
3. Copy `.env.example` → `.env` in each app/service and set keys (MAPBOX token, etc.).
4. `pnpm i && pnpm dev` at repo root to run pipelines.

## Environments
- `dev` (default) — iterate quickly
- `prod` — branch-protected, CI required

## Contributing
See [CONTRIBUTING.md](CONTRIBUTING.md) and our [Code of Conduct](CODE_OF_CONDUCT.md). Create issues using templates in **New Issue**.

## License
MIT © 2025 BiteBrain contributors
