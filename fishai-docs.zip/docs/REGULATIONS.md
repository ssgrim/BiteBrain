# Regulations Strategy

- Provide a **snapshot** summary with a prominent link to the official regulations page for the selected waterbody/species.
- Show “Last checked” timestamp and allow user-pinned notes with expiry.
- Always advise the angler to verify on the water; regulations change.
