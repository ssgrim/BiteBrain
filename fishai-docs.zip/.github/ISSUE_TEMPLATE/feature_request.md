---
name: Feature request
about: Suggest an idea
labels: feat
---

**Problem / user story**

**Proposal**

**Acceptance criteria**
- [ ] …
