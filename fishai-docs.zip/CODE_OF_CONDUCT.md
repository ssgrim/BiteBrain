# Code of Conduct

We are committed to a welcoming, harassment-free project. Be kind, assume good intent, and collaborate respectfully.

- Be inclusive. No discrimination or harassment.
- Be constructive. Critique ideas, not people.
- Respect privacy and safety on the water and in code.

Violations may be reported privately to the maintainers for remediation or removal from the community.
