# BiteBrain Animated Showcase

This pack contains:
- Icons (zombie fish detailed, badge, outline)
- Animated wallpapers (light & dark, 1280×720 demo sizes)

Usage notes:
- For animations to play, embed SVG inline or via <object>, not as <img> or CSS background.
- Animations respect prefers-reduced-motion.

Folders:
- icons/
- wallpapers/

Enjoy!
