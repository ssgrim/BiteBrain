export type Conditions = {
  season: 'pre-spawn' | 'spawn' | 'post-spawn' | 'summer' | 'fall' | 'winter';
  waterTempF?: number;
  windMph?: number;
  sky?: 'sunny' | 'cloudy' | 'mixed';
  clarity?: 'clear' | 'stained' | 'muddy';
};

export type Recommendation = {
  pattern: string;
  lures: { name: string; details: string }[];
};

export function recommend(c: Conditions): Recommendation[] {
  // tiny deterministic mock for bootstrapping
  if (c.season === 'pre-spawn' && c.sky !== 'sunny') {
    return [
      { pattern: 'Wind-blown secondary points', lures: [
        { name: 'Chatterbait 3/8 oz', details: 'white/chartreuse + paddletail, slow roll' },
        { name: 'Flat-side crank', details: 'red/orange, deflect off rock' },
        { name: 'Ned 1/10 oz', details: 'green pumpkin, shake + dead-stick' }
      ]}
    ];
  }
  return [
    { pattern: 'Dock shade finesse', lures: [
      { name: 'Wacky Stick Worm', details: '5", natural greens' },
      { name: 'Dropshot 1/4 oz', details: '3" minnow, nose-hooked' },
      { name: 'Swim jig 1/4 oz', details: 'bluegill colors, slow roll' }
    ]}
  ];
}
