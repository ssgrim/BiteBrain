import { recommend } from '@fishai/core';
export const handler = async () => {
  const recs = recommend({ season: 'pre-spawn', sky: 'cloudy' });
  return { statusCode: 200, body: JSON.stringify(recs) };
};
