# Fishing/Kayak AI Assistant

**One-liner:** AI that fuses local weather, seasonal bite patterns, and *your* tackle inventory to recommend **where/when/what** to fish — with maps, regs snapshots, and offline trip plans.

## Monorepo Layout (Turborepo-ready)
```
/apps
  /web        # Next.js app (to be scaffolded)
  /mobile     # Expo React Native app (to be scaffolded)
/packages
  /ui         # shared UI components (Tailwind + shadcn) — TBD
  /core       # scoring engine, species/season data (TypeScript)
/services
  /api        # AWS Lambda handlers (Node/TS)
/infra
  /terraform  # IaC for AWS (API, Cognito, DynamoDB, S3, CloudFront)
```

## Quick Start
1. Open in **GitHub Codespaces** (or locally with Node LTS and pnpm).
2. Open `PROMPT.md` and **run the prompt** with Codespaces AI/Copilot to finish scaffolding.
3. Rename the app in `package.json` and set your secrets in `.env.example` files.

## Feature Flags
- `OFFLINE_TILES`: enable offline map tiles for a selected lake
- `KAYAK_MODE`: wind alerts + safe-lane overlays
- `LLM_HELPER`: natural-language pattern explainer

## OSS License
MIT — see [LICENSE](./LICENSE)
